﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Assigment_1
{
    abstract class Unit
    {
        protected int xPosition;
        protected int yPosition;
        protected int health;
        protected int speed;
        protected int attack;
        protected int attackRange;
        protected string team;
        protected PictureBox image;

        protected Unit thisenemy;


        public abstract void Movement();
        public abstract bool inRange();
        public abstract void ClosestEn(Unit Allunit);
       
        public abstract void TakeDamge();
        public abstract int CalDamage();
        public abstract int Getxposition();
        public abstract int Getyposition();
        public abstract int Gethealth();
        public abstract void Direction(int health);
        public abstract string Getteam();
        public abstract PictureBox Getimagename();
        public abstract Unit GetEnemy();
        public abstract bool death();
        public abstract string Tostring();
       
       


      

    }
}
