﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace Assigment_1
{
    class Map 
    {

        public int unit;
        public int Total;
        public int count;
        Random num = new Random();
        public PictureBox[] picture;
        Form1 fm;
        public MeleeUnit[] warrior;
        public RangedUnit[] archer;
        public int numOfW;
        public int numOfA;
        public Unit[] list;
        public Point[] UnitLoc;
        public Map(ref Form1 s)
        {
            fm = s;
          
           
             
        }

        public void Generate(ref Form1 fm)
        {   
            Total =50;
            count = 0;
            picture = new PictureBox[Total];
            warrior = new MeleeUnit[Total];
            archer = new RangedUnit[Total];
            UnitLoc = new Point[Total];
            numOfW = 0;
            numOfA = 0;
            list = new Unit[Total];

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    unit = num.Next(10); // the % of generate on the current block 
                    if (unit == 0 && Total > 0)
                    {
                        Total--;
                        unit = num.Next(4); //generate class and team
                        Point newpoint = new Point(j * 20, i * 20);
                        UnitLoc[count] = newpoint;
                        Size newsize = new Size(20, 20);
             //           MessageBox.Show(count.ToString());
                       
                        picture[count] = new PictureBox();
                   //     picture[count].Parent =  ;
                        picture[count].Location = newpoint;
                        picture[count].Size = newsize;
                        picture[count].SizeMode = PictureBoxSizeMode.Zoom;
                        switch (unit) //create in which team and which class unit
                        {
                            case 0:
                                {

                                    picture[count].Image = (Bitmap)Image.FromFile("Warrior.png");
                                    picture[count].Name = "RW" + (count + 1);

                                    warrior[numOfW] = new MeleeUnit(i * 20, j * 20, 100, 10, 12, 1, "Red", picture[count]);
                                    list[count] = warrior[numOfW];
                                    numOfW++;
                                }
                                break;
                            case 1:
                                {
                                    picture[count].Image = (Bitmap)Image.FromFile("archer.png");
                                    picture[count].Name = "RA" + (count + 1);

                                    archer[numOfA] = new RangedUnit(i * 20, j * 20,80, 8, 15, 2, "Red", picture[count]);
                                    list[count] = archer[numOfA];
                                    numOfA++;
                                }
                                break;
                            case 2:
                                {
                                    picture[count].Image = (Bitmap)Image.FromFile("Warrior2.png");
                                    picture[count].Name = "BW" + (count + 1);

                                    warrior[numOfW] = new MeleeUnit(i * 20, j * 20,100, 10, 12, 1, "Blue", picture[count]);
                                    list[count] = warrior[numOfW];
                                    numOfW++;
                                }
                                break;
                            case 3:
                                {
                                    picture[count].Image = (Bitmap)Image.FromFile("archer2.png");
                                    picture[count].Name = "BA" + (count + 1);


                                    archer[numOfA] = new RangedUnit(i * 20, j * 20, 80, 8, 15, 2, "Blue", picture[count]);
                                    list[count] = archer[numOfA];
                                    numOfA++;
                                }
                                break;
                        }

                        fm.Controls.Add(picture[count]);
                        
                        count++;

                    }             
                }
            }

            Total = numOfA + numOfW;
        }

        public  void updateMap()
        {   
            for (int i = 0; i < count; i++)
            {
              //  fm.Controls.Remove(picture[i]);
                UnitLoc[i] = list[i].Getimagename().Location;// All unit on map is update but this will not control picturebox location
          //      fm.Controls.Add(list[i].Getimagename());
            }
        }

        public void movelocation(Unit thisunit) // this is the one control picturebox location
        {
            Point thispoint= new Point( thisunit.Getyposition(),thisunit.Getxposition()); // point got

            thisunit.Getimagename().Location = thispoint;
            

        }

    }
}
