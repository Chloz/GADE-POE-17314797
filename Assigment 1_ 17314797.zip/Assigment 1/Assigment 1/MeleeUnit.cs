﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Assigment_1
{
    class MeleeUnit : Unit
    {

        public int distense;
        public MeleeUnit(int x, int y,int health, int speed, int attack, int range, string team , PictureBox pic )
        {
            this.xPosition = x; 
            this.yPosition = y;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = range;
            this.team = team;
            this.image = pic;
            thisenemy = this;
            
            distense = 320000; // MAX distence that without square root it in 20x20 block and 20x20 size block;
            

        }
        public int direction;

        public override void Movement()
        {

            this.Direction(health);

           

            switch (direction)
            {

                case 0: //in battle
                    {
                        thisenemy.TakeDamge();
                        // Tested. enemy health are successful damage and now....
                        
                    }
                    break;
                case 1: //up
                    {
                        if (yPosition>0)
                        {
                            yPosition -= 20;
                        }
                           
                    }
                    break;
                case 2: //down
                    {
                        if (yPosition<400)
                        {
                            yPosition += 20;
                        } 
                       
                    }
                    break;
                case 3: //right
                    {
                        if (xPosition < 400)
                        {
                            xPosition += 20;
                        }
                    }
                    break;
                case 4: //left
                    {
                        if (xPosition >0)
                        {
                            xPosition -= 20;
                        }
                    }
                    break;
            }

            distense = 320000; //re- find from the map as max range.  
        }
        public override void TakeDamge() // to enemy
        {
            if (thisenemy.inRange() == true) // if in range then attack
            {
                health -= thisenemy.CalDamage();
                if (health <= 0)
                {
                    health = 0; //enemy dead

                }

            }
            else
            {
                //false mean? no enemy on map or enemy not in range
            }

        }

        public override void Direction(int health1)
        {
            health = health1;
            if (health > 25 )
            {

                if (thisenemy.Getxposition() - xPosition > 20)
                {
                    direction = 3;
                }
                else if (thisenemy.Getxposition() - xPosition < -20)
                {
                    direction = 4;
                }
                else if (thisenemy.Getyposition() - yPosition < -20)
                {
                    direction = 1;
                }
                else if (thisenemy.Getyposition() - yPosition > 20)
                {
                    direction = 2;
                }
                else 
                {
                    direction = 0; // stay combat
                }

                //direction solved
            }
            else if (health <= 25 )
            {
                Random r = new Random();
                direction=r.Next(1, 4);
            }
        }

        public override int CalDamage()
        {
            return attack;
        }
        public override int Getxposition()
        {
            return xPosition;
        }
        public override int Getyposition()
        {
            return yPosition;
        }

        public override string Tostring()
        {
            string text = "Team: " + team + " "+ image.Name+" HP: "+health+" Attk: "+attack+" speed:"+speed;
            return text;
        }

        public override bool inRange()
        {

            int xgap = xPosition - thisenemy.Getxposition();
            int ygap = yPosition - thisenemy.Getyposition();
            if ((xgap >= -20) && (xgap <= 20) && (ygap >= -20) && (ygap <= 20)) //0 mean will not attk himself
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override int Gethealth()
        {
            return health;
        }

        


        public override PictureBox Getimagename()
        {
            return image;
        }

        public override string Getteam()
        {
            return team;
        }


        public override void ClosestEn(Unit enemy)// no matter is Ranged or Melee, they will go to their own Unit class
        {
           // int distence = 100;
            int tempx = xPosition - enemy.Getxposition() ; //400 - 0 20block, 1 block 20 position
            int tempy = yPosition - enemy.Getyposition();  // 400 - 0
            int newdistence = (tempx *tempx+  tempy * tempy) ; //  320000 max math.sqrt doesnt work
    //        MessageBox.Show(newdistence.ToString());
            if (newdistence <distense) // searching the closet enemy
            {
                distense = newdistence;
               thisenemy = enemy;
         //       MessageBox.Show(thisenemy.Tostring());
                //sdasd
            }
            else 
            {
                
            }

         //   return thisenemy;

        }



        public override Unit GetEnemy()
        {
            return thisenemy;
        }

        public override bool death()
        {
            return true;
        }
         
    }
}
