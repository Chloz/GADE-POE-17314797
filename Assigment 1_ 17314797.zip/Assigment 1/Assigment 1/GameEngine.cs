﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigment_1
{  
    class GameEngine
    {
        public Form1 s;
        public Map mymap;  
        public RichTextBox box;
        public Timer T;
        public Label L;
        public Button start;
        public int i;
        public int win;
        public string winner;
        public int sec;
        public int min;

        
        public GameEngine(ref Form1 f,ref RichTextBox a,ref Timer timer1 , ref Label L1 ,ref Button begin)
        {
            s = f;
             mymap = new Map(ref s);
            mymap.Generate(ref s);
            box = a;
            T = timer1;
            L = L1;
            sec = 0;
            min = 0;
            start = begin;
           
            
        }

        public void update() //run in every second
        {


            win = 0;
            winner = "";
            box.Text = "";// clean the display otherwise too many information
            sec++;
            if (sec == 60)
            {

                sec = 0;
                min++;
            }

            if (sec < 10)
            {
                L.Text = "0" + min + ":0" + sec;
            }
            else
            {
                L.Text = "0" + min + ":" + sec;
            }


            for (i = 0; i< mymap.count-1;i++)
            {
                if (mymap.list[1].Getteam()== mymap.list[i+1].Getteam())
                {
                    win++;
                }
            }

            if (win == mymap.count - 1)
            {
                box.Text=(mymap.list[0].Getteam() + " team Wins! They have " + win+" Units leave");
                T.Enabled = false;
                for (i = 0; i < mymap.count ; i++)
                {
                    s.Controls.Remove(mymap.list[i].Getimagename());
                }
                start.Enabled = true; ;

            }
            else
            {
                for (i = 0; i < mymap.count; i++)
                {

                    // look for Class unit in array list and call method to their Unit class 
                    if (mymap.list[i].Getteam() == "Blue") //current Class unit as Blue team unit
                    {


                        for (int j = 0; j < mymap.count; j++)
                        {
                            if (mymap.list[j].Getteam() == "Red") // get Red team unit position
                            {
                                mymap.list[i].ClosestEn(mymap.list[j]);
                            }

                        }

                    }
                    else //As Red team 
                    {
                        for (int j = 0; j < mymap.count; j++)
                        {
                            if (mymap.list[j].Getteam() == "Blue") //Get blue team unit
                            {
                                mymap.list[i].ClosestEn(mymap.list[j]);
                            }

                        }
                    }


                    mymap.list[i].Direction(mymap.list[i].Gethealth()); // post health to methed for attack or runway action

                    mymap.list[i].Movement(); //enemy got damage
                                              // unit which hp lower than 25% are now run away in random direction


                }

                for (i = 0; i < mymap.count; i++)
                {
                    //     MessageBox.Show(mymap.list[i].Tostring());
                    if (mymap.list[i].Gethealth() == 0)
                    {
                        // Question: IF list[i] is at the end of the array list?
                        s.Controls.Remove(mymap.list[i].Getimagename());
                        for (int j = i; j < mymap.count - 1; j++)
                        {

                            mymap.list[j] = mymap.list[j + 1];
                        }
                        mymap.count--; //Question solved, this unit will not show on list anymore
                    }
                    box.Text = box.Text + "\n" + mymap.list[i].Tostring();
                    mymap.movelocation(mymap.list[i]);
                }

                mymap.updateMap();
            }


        }

    }



}//end  line ________________________________________________________________________________


//Tested code:

/*      for (int j = 0; j < mymap.numOfW; j++)
                       {
                           if (mymap.warrior[j ].Getteam() == "Red") //get red warrior
                           {
                               mymap.archer[i ].ClosestEn(mymap.warrior[j ]);
                           }
                       }


                       for (int j = 0; j < mymap.numOfA; j++)
                       {
                           if (mymap.archer[j ].Getteam() == "Red") //get red archer
                           {
                               mymap.archer[i ].ClosestEn(mymap.archer[j ]);
                           }
                       }*/

//Tested 2;
// find the closet enemy and move one time

/*            for (int i = 0; i < mymap.numOfW; i++)  // warrior has higher speed
            {
                if (mymap.warrior[i].Getteam() == "Red")//if this is red, red find blue enemy
                {

                    for (int j = 0; j < mymap.count; j++)
                    {
                        if (mymap.list[j].Getteam() == "Blue")
                        {
                            mymap.warrior[i].ClosestEn(mymap.list[j]);
                        }

                    }
                }

                if (mymap.warrior[i ].Getteam() == "Blue")//if is blue then samething
                {

                    for (int j = 0; j < mymap.count; j++)
                    {
                        if (mymap.list[j].Getteam() == "Red")
                        {
                            mymap.warrior[i].ClosestEn(mymap.list[j]);
                        }

                    }

                }
                //this warrior got his enemy position now moving, Var thisenemy was stored in Meleeunit
                if (mymap.warrior[i ].Gethealth() < 25)
                {

                }

                mymap.warrior[i ].Movement(); // now to move or to attack.

        //        MessageBox.Show(mymap.warrior[i].ToString());
                box.Text = box.Text + "\n" + mymap.warrior[i].Tostring();

                mymap.movelocation(mymap.warrior[i]);

            }


            //All warrior finish their round
            //now archer turn++++++++++++++++++++++

            for (int i = 0; i < mymap.numOfA; i++)  // archer bit slower
            {
                if (mymap.archer[i ].Getteam() == "Red")//if this is red, red find blue enemy
                {

                    for (int j = 0; j < mymap.count; j++)
                    {
                        if (mymap.list[j].Getteam() == "Blue")
                        {
                            mymap.archer[i].ClosestEn(mymap.list[j]);
                        }

                    }
                }

                if (mymap.archer[i ].Getteam() == "Blue")//if is blue then same thing
                {


                    for (int j = 0; j < mymap.count; j++)
                    {
                        if (mymap.list[j].Getteam() == "Red")
                        {
                            mymap.archer[i].ClosestEn(mymap.list[j]);
                        }

                    }

                }
                //this archer got his enemy position now moving, Var thisenemy was stored in Rangeunit



                mymap.archer[i ].Movement(); // now to move or to attack.
                box.Text = box.Text + "\n" + mymap.archer[i].Tostring();
                //picture move by call method
                mymap.movelocation(mymap.archer[i]); 


            }           */
