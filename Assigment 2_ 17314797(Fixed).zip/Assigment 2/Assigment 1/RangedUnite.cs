﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1//2
{   [Serializable]
    class RangedUnit :Unit
    {
        public int distense;
        public int distense2; //for building 
        public RangedUnit(string name, int x, int y, int health, int speed, int attack, int range, string team, string pic)
        {
            this.xPosition = x;
            this.yPosition = y;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = range;
            this.team = team;
            this.image = pic;
            this.name = name;
           
            thisenemy = this;
            distense = 320000;
            distense2 = 320000;

        }
        public int direction;

        public override int X
        {
            get
            {
                return xPosition;
            }

            set
            {
                xPosition = value;
            }
        }

        public override int y
        {
            get { return yPosition; }
            set { yPosition = value; }
        }
        public override int Health
        {
            get { return health; }
            set { health = value; }
        }
        public override int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public override string Team
        {
            get { return team; }
            set { team = value; }
        }
        public override int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public override int AttackRange
        {
            get { return attackRange; }
            set { attackRange = value; }
        }
        public override string Name
        {
            get { return name; }
            set { name = value; }
        }
        public override string Image
        {
            get { return image; }
            set { image = value; }
        }


        public override void Save()
        {
            //    Unit 
            FileStream saveFile = new FileStream("saves/units.game", FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(saveFile);
           
            writer.WriteLine(Name + "," + X + "," + y + "," + Health + "," + Team);
            Console.WriteLine("Data written");
            writer.Close();
            saveFile.Close();
        }

        public override void Load()
        {
         //   throw new NotImplementedException();
        }



        public override void Movement()
        {


            this.Direction(health);
            switch (direction)
            {

                case 0: //in battle
                    {
                        if (distense < distense2) // enemy unit is cloest than enemy building
                        {
                            thisenemy.TakeDamge();
                        }
                        else
                        {
                            thisbuilding.TakeDamge(this);
                        }
                    }
                    break;
                case 1: //up
                    {
                        if (yPosition > 0)
                        {
                            yPosition -= 20;
                        }

                    }
                    break;
                case 2: //down
                    {
                        if (yPosition < 400)
                        {
                            yPosition += 20;
                        }

                    }
                    break;
                case 3: //right
                    {
                        if (xPosition < 400)
                        {
                            xPosition += 20;
                        }
                    }
                    break;
                case 4: //left
                    {
                        if (xPosition > 0)
                        {
                            xPosition -= 20;
                        }
                    }
                    break;
            }
            distense = 320000; //re- find from the map as max range.
            distense2 = 320000;
        }
        public override void TakeDamge() // to enemy
        {
            if (thisenemy.inRange() == true) // if in range then attack
            {
                health -= thisenemy.CalDamage();
                if (health <= 0)
                {
                    health = 0;
                    death();
                }

            }

        }



        public override void Direction(int health)
        {
            if (distense <= distense2)
            {
                if (health > 20)
                {

                    if (thisenemy.Getxposition() - xPosition > 20)
                    {
                        direction = 3;
                    }
                    else if (thisenemy.Getxposition() - xPosition < -20)
                    {
                        direction = 4;
                    }
                    else if (thisenemy.Getyposition() - yPosition < -20)
                    {
                        direction = 1;
                    }
                    else if (thisenemy.Getyposition() - yPosition > 20)
                    {
                        direction = 2;
                    }
                    else
                    {

                        direction = 0; // stay combat
                    }

                    //direction solved
                }
                else if (health <= 25)
                {
                    Random r = new Random();
                    direction = r.Next(1, 4);
                }
            }
            else // if building is closet than go to building
            {
                if (thisbuilding.Getxposition() - xPosition > 20)
                {
                    direction = 3;
                }
                else if (thisbuilding.Getxposition() - xPosition < -20)
                {
                    direction = 4;
                }
                else if (thisbuilding.Getyposition() - yPosition < -20)
                {
                    direction = 1;
                }
                else if (thisbuilding.Getyposition() - yPosition > 20)
                {
                    direction = 2;
                }
                else
                {

                    direction = 0; // stay combat
                }
            }



        }


        public override int CalDamage()
        {
            return attack;
        }
        public override int Getxposition()
        {
            return xPosition;
        }
        public override int Getyposition()
        {
            return yPosition;
        }

        public override string Tostring()
        {
            return team + " " + name + " HP: " + health + " Attk: " + attack + " speed:" + speed;
        }

        public override bool inRange() 
        {

            int xgap = xPosition - thisenemy.Getxposition();
            int ygap = yPosition - thisenemy.Getyposition();
            if ((xgap >= -40) && (xgap <= 40) && (ygap >= -40) && (ygap <= 40) )
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool inRangeB()
        {

            int xgap = xPosition - thisbuilding.Getxposition();
            int ygap = yPosition - thisbuilding.Getyposition();
            if ((xgap >= -40) && (xgap <= 40) && (ygap >= -40) && (ygap <= 40))
            {
                return true;
            }
            else
            {
                return false;


            }
        }

        public override int Gethealth()
        {
            

            return health;
        }



        public override string Getimagename()
        {
            return image;
        }

        public override string Getteam()
        {
            return team;
        }


        
        public override void ClosestEn(Unit enemy) // no matter is Ranged or Melee
        {
            // int distence = 100;
            int tempx = xPosition - enemy.Getxposition();
            int tempy = yPosition - enemy.Getyposition();
            int newdistence = (tempx * tempx + tempy * tempy);
            if (newdistence < distense) // searching the closet enemy
            {
                distense = newdistence;
                thisenemy = enemy;
            }
            else
            {

            }
        //    return thisenemy;
        }

        public override void ClosestBu(Building build)
        {
            int tempx = xPosition - build.Getxposition();
            int tempy = yPosition - build.Getyposition();
            int newdistence = (tempx * tempx + tempy * tempy);
            if (newdistence < distense2) // searching the closet building
            {
                distense2 = newdistence;
                thisbuilding = build;
            }
            else
            {

            }
        }

        public override Unit GetEnemy()
        {
            return thisenemy;
        }

        public override bool death()
        {
            return true;
        }

    }
}
