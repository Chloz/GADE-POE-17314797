﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1//2
{  [Serializable]
    abstract  class Building
    {
        protected int xPosition;
        protected int yPosition;
        protected int health;
        protected string type;
        protected string team;
        protected string image;
        protected int remain;
        protected int amount;

        protected string name;

        public abstract int X
        {
            get;
            set;
        }

        public abstract int y
        {
            get;
            set;
        }
        public abstract int Health
        {
            get;
            set;
        }
        public abstract string Type
        {
            get;
            set;
        }
        public abstract string Team
        {
            get;
            set;
        }
        public abstract int Remain
        {
            get;
            set;
        }
        public abstract int Amount
        {
            get;
            set;
        }
        public abstract string Image { get; set; }




        public abstract void movement(ref int num);
        public abstract bool product();
        public abstract string unit();
        public abstract void TakeDamge(Unit a);
        public abstract int Getxposition();
        public abstract int Getyposition();
        public abstract int gethealth();
        public abstract bool death();
        public abstract string Tostring();
        public abstract string Getimagename();
        public abstract string Getteam();
        public abstract string Getname();

        public abstract void Save();
        public abstract void Load();

    }
}
