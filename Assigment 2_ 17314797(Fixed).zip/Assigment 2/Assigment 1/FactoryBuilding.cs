﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1
{ [Serializable]
    class FactoryBuilding : Building
    {


        public string[,] a;
        public bool f1;
        public FactoryBuilding(int x, int y,  string team, string pic)
        {
            this.xPosition = x;
            this.yPosition = y;
            this.health = 100;
            this.team = team;
            this.image = pic;
            this.name = "Train house";
            this.remain = 0; // number of unit on list
            a = new string[200, 2];
            f1 = false;
        }



        public override int X
        {
            get
            {
                return xPosition;
            }

            set
            {
                xPosition = value;
            }
        }

        public override int y
        {
            get { return yPosition; }
            set { yPosition = value; }
        }
        public override int Health
        {
            get { return health; }
            set { health = value; }
        }
        public override string Type
        {
            get { return type; }
            set { type = value; }
        }
        public override string Team
        {
            get { return team; }
            set { team = value; }
        }
        public override int Remain
        {
            get { return remain; }
            set { remain = value; }
        }
        public override int Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public override string Image
        {
            get { return image; }
            set { image = value; }
        }









        public override void movement(ref int Tgold)
        {



            f1 = false;
            if (remain >0 )
            {

                 

                    if ( a[0, 1] =="0")
                    {
                    for (int i = 0  ; i < remain; i++)
                    {
                        
                        a[i,0] = a[i+1,0];
                        a[i, 1] = a[i + 1, 1];
                    }
                    remain--;
                    }


               


                for (int i = 0; i < remain; i++)
                {
                    a[i, 1] =  Convert.ToString(Convert.ToInt32(a[i, 1])-1);
                    if (a[i, 1] =="-1")
                    { a[i, 1] = "0"; }

                  if (a[0, 1] == "0")
                  {

                       
                        f1 = true;
                        

                    }
                    else
                    {
                        f1 = false;
                    }
                }
            }

            if (Tgold > 7)
            {  
                
                Random r = new Random();
                int num = r.Next(2);
                if (num == 0)
                {

                    a[remain,0] = "Warrior";
                    a[remain, 1] = "2";
                    Tgold -= 5;
                    
                }
                else if( num ==1)
                {
                    a[remain, 0] = "Archer";
                    a[remain, 1] = "3";
                    Tgold -= 7;

                }
                remain++;
            }

           




        }

        public override bool product()
        {
            return f1;
        }

        public override string unit()
        {
            // nothing
            return a[0,0];

        }


        public  override int Getxposition() // return this x position, units spawn on the point of the factory building
        {
            return xPosition;
        }
        public override int Getyposition()
        {
            return yPosition;
        }

        public override int gethealth()
        {
            return health;
        }

        public override string Getname()
        {
            return name;
        }


     


        public override void TakeDamge(Unit a)
        {
            if (a.inRangeB() == true) // if in range then attack
            {

                health -= a.CalDamage();
                if (health <= 0)
                {
                    health = 0;
                    death();
                }

            }
           
        }

        public override string Getimagename()
        {
            return image;
        }

        public override string Getteam()
        {
            return team;
        }

        public override void Save()
        {
            //    Unit 
            FileStream saveFile = new FileStream("saves/buildings.game", FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(saveFile);

            writer.WriteLine(this.name + "," + X + "," + y + "," + Health + "," + Team+","+ Remain);
            Console.WriteLine("Data written");
            writer.Close();
            saveFile.Close();
        }

        public override void Load()
        {
    //        throw new NotImplementedException();
        }

        public override bool death()
        {
            if (gethealth() == 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        public override string Tostring()
        {
           
            return team + " Train house HP: " + health +" Remain "+ remain;
        }
    }
}
