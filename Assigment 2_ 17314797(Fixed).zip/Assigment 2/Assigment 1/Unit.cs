﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1 //2
{  [Serializable]
    abstract class Unit
    {
        protected int xPosition;
        protected int yPosition;
        protected int health;
        protected int speed;
        protected int attack;
        protected int attackRange;
        protected string team;
        protected string image;
        protected string name;

        protected Unit thisenemy;
        protected Building thisbuilding;


        public abstract int X
        {
            get;
            set;
        }

        public abstract int y
        {
            get;
            set;
        }
        public abstract int Health
        {
            get;
            set;
        }
        public abstract int Speed
        {
            get;
            set;
        }
        public abstract string Team
        {
            get;
            set;
        }
        public abstract int Attack
        {
            get;
            set;
        }
        public abstract int AttackRange
        {
            get;
            set;
        }
        public abstract string Name
        {
            get;
            set;
        }
        public abstract string Image { get; set; }


        public abstract void Movement();
        public abstract bool inRange();
        public abstract bool inRangeB();
        public abstract void ClosestEn(Unit Allunit);
        public abstract void ClosestBu(Building Allunit);

        public abstract void TakeDamge();
        public abstract int CalDamage();
        public abstract int Getxposition();
        public abstract int Getyposition();
        public abstract int Gethealth();
        public abstract void Direction(int health);
        public abstract string Getteam();
        public abstract string Getimagename();
        public abstract Unit GetEnemy();
        public abstract bool death();

        public abstract void Save();
        public abstract void Load();

        public abstract string Tostring();
       
       


      

    }
}
