﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// jialuo chen 17314797
namespace Assigment_1
{
    public partial class Form1 : Form
    {
        Form1 f;
        GameEngine game;
        RichTextBox rt;
        bool run;
        public Form1()
        {
            InitializeComponent();
            f = this;
            rt = this.richTextBox1;
            run = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {  
            
       
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            game.update();

            
        }

        private void Start_Click(object sender, EventArgs e)
        {
            if (run == true)
            {
                game = new GameEngine(ref f, ref richTextBox1, ref timer1, ref label2, ref Start);
                
            }
            else
            {
                
                run = true;
            }
            timer1.Enabled = true;
            Start.Enabled = false;
            Stop.Enabled = true;

        }

        private void Stop_Click(object sender, EventArgs e)
        {
            timer1.Enabled =false;
            run = false;
            Start.Enabled = true;
            Stop.Enabled = false;

        }
    }
}
