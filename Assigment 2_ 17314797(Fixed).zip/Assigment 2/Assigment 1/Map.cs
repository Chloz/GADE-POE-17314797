﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1
{  [Serializable]
    class Map 
    {

        public int unit;
        public int Total;
        public int count;
        public int bcount;
        public int count2;
        Random num = new Random();
        public PictureBox[] picture;
        Form1 fm;
        public MeleeUnit[] warrior;
        public RangedUnit[] archer;
        public int numOfW;
        public int numOfA;
        public int numOfR;
        public int numOfF;
        public Unit[] list;
        public Point[] UnitLoc;

        public ResourceBuilding[] goldmine;
        public FactoryBuilding[] trainhouse;
            
        public Building[] buildlist;

        public Map(ref Form1 s)
        {
            fm = s;
          
           
             
        }

        public void Generate(ref Form1 fm)
        {   
            Total =500;
            count = 0;
            count2 = 0;
            bcount = 0;
            picture = new PictureBox[Total];
            warrior = new MeleeUnit[Total];
            archer = new RangedUnit[Total];
            UnitLoc = new Point[Total];
            numOfW = 0;
            numOfA = 0;


            goldmine = new ResourceBuilding[Total];
            trainhouse = new FactoryBuilding[Total];
            numOfR = 0;
            numOfF=0;
            buildlist = new Building[Total];
            list = new Unit[Total];

            //array set total 100

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    unit = num.Next(10); // the % of generate on the current block 
                    if (unit == 0 && Total > 0)
                    {
                        Total--;
                        unit = num.Next(5); //generate class and team
                        Point newpoint = new Point(j * 20, i * 20);
                        UnitLoc[count2] = newpoint;
                        Size newsize = new Size(20, 20);
             //           MessageBox.Show(count.ToString());
                       
                        picture[count2] = new PictureBox();
                   //     picture[count].Parent =  ;
                        picture[count2].Location = newpoint;
                        picture[count2].Size = newsize;
                        picture[count2].SizeMode = PictureBoxSizeMode.Zoom;

                        switch (unit) //create in which team and which class unit
                        {
                            case 0:
                                {

                                    picture[count2].Image = (Bitmap)Image.FromFile("Warrior.png");
                                    picture[count2].Name = "RW" + (count2 + 1);

                                    warrior[numOfW] = new MeleeUnit("Warrior",i * 20, j * 20, 100, 10, 12, 1, "Red", picture[count2].Name);
                                    list[count] = warrior[numOfW];
                                    numOfW++;

                                 
                                }
                                break;
                            case 1:
                                {
                                    picture[count2].Image = (Bitmap)Image.FromFile("archer.png");
                                    picture[count2].Name = "RA" + (count2 + 1);

                                    archer[numOfA] = new RangedUnit("Archer",i * 20, j * 20,80, 8, 15, 2, "Red", picture[count2].Name);
                                    list[count] = archer[numOfA];
                                    numOfA++;

                                   
                                }
                                break;
                            case 2:
                                {
                                    picture[count2].Image = (Bitmap)Image.FromFile("Warrior2.png");
                                    picture[count2].Name = "BW" + (count2 + 1);

                                    warrior[numOfW] = new MeleeUnit("Warrior",i * 20, j * 20,100, 10, 12, 1, "Blue", picture[count2].Name);
                                    list[count] = warrior[numOfW];
                                    numOfW++;

                                
                                }
                                break;
                            case 3:
                                {
                                    picture[count2].Image = (Bitmap)Image.FromFile("archer2.png");
                                    picture[count2].Name = "BA" + (count2 + 1);


                                    archer[numOfA] = new RangedUnit("Archer",i * 20, j * 20, 80, 8, 15, 2, "Blue", picture[count2].Name);
                                    list[count] = archer[numOfA];
                                    numOfA++;

                                   
                                }
                                break;
                            case 4: 
                                {

                                    unit = num.Next(4);
                                    if (unit == 0)
                                    {
                                        picture[count2].Image = (Bitmap)Image.FromFile("resourcebuild1.png");
                                        picture[count2].Name = "RB" + (count2 + 1);

                                        goldmine[numOfR] = new ResourceBuilding(i * 20, j * 20, "Red", picture[count2].Name);
                                        buildlist[bcount] = goldmine[numOfR];

                                        numOfR++;
                                    }
                                    else if (unit == 1)
                                    {
                                        picture[count2].Image = (Bitmap)Image.FromFile("resourcebuild2.png");
                                        picture[count2].Name = "RB" + (count2 + 1);

                                        goldmine[numOfR] = new ResourceBuilding(i * 20, j * 20, "Blue", picture[count2].Name);
                                        buildlist[bcount] = goldmine[numOfR];

                                        numOfR++;
                                    }
                                    else if (unit == 2)
                                    {
                                        picture[count2].Image = (Bitmap)Image.FromFile("factorybuild1.png");
                                        picture[count2].Name = "RB" + (count2 + 1);

                                        trainhouse[numOfF] = new FactoryBuilding(i * 20, j * 20, "Red", picture[count2].Name);
                                        buildlist[bcount] = trainhouse[numOfF];

                                        numOfF++;
                                    }
                                    else 
                                    {
                                        picture[count2].Image = (Bitmap)Image.FromFile("factorybuild2.png");
                                        picture[count2].Name = "RB" + (count2 + 1);

                                        trainhouse[numOfF] = new FactoryBuilding(i * 20, j * 20, "Blue", picture[count2].Name);
                                        buildlist[bcount] = trainhouse[numOfF];

                                        numOfF++;
                                    }
                                    bcount++;
                                    count--;
                                    
                                }
                                break;


                        }

                        fm.Controls.Add(picture[count2]);

                        count++;
                        count2++;

                    }             
                }
            }

         

            
        }

        public  void updateMap()
        {   
            for (int i = 0; i < count2; i++)
            {
              //  fm.Controls.Remove(picture[i]);
                UnitLoc[i] = picture[i].Location;// All unit on map is update but this will not control picturebox location
          //      fm.Controls.Add(list[i].Getimagename());
            }
        }

        public void movelocation(Unit thisunit) // this is the one control picturebox location
        {
            Point thispoint= new Point( thisunit.Getyposition(),thisunit.Getxposition()); // point got

            for (int i = 0; i < count2; i++)
            {
                if (thisunit.Getimagename()==picture[i].Name)
                    picture[i].Location = thispoint;
            }

        }

        public void Load()
        {
            Total = 500;
            count = 0;
            count2 = 0;
            bcount = 0;
            picture = new PictureBox[Total];
            warrior = new MeleeUnit[Total];
            archer = new RangedUnit[Total];
            UnitLoc = new Point[Total];
            numOfW = 0;
            numOfA = 0;


            goldmine = new ResourceBuilding[Total];
            trainhouse = new FactoryBuilding[Total];
            numOfR = 0;
            numOfF = 0;
            buildlist = new Building[Total];
            list = new Unit[Total];

            loadunit();
            loadbuilding();
        }

        public void loadunit()
        {
            FileStream saveFile = new FileStream("saves/units.game", FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(saveFile);
            int numUnits = File.ReadAllLines("saves/units.game").Length;
            Unit[] loadedUnits = new Unit[numUnits];
            string line = reader.ReadLine();
            int c = 0;
            Unit createdUnit = null;
            while (line != null)
            {
                string[] temp = line.Split(',');
                //determine what unit to make
                //build the unit
                //assign the unit to the array
                Point newpoint = new Point(int.Parse(temp[2]), int.Parse(temp[1]));
                UnitLoc[count2] = newpoint;
                Size newsize = new Size(20, 20);
                //           MessageBox.Show(count.ToString());

                picture[count2] = new PictureBox();
                //     picture[count].Parent =  ;
                picture[count2].Location = newpoint;
                picture[count2].Size = newsize;
                picture[count2].SizeMode = PictureBoxSizeMode.Zoom;
                if ((temp[0] == "Archer"))
                {
                    //ranged
                    //"Archer",i * 20, j * 20, 80, 8, 15, 2, "Blue", picture[count2].Nam
                    //(Name + "," + X + "," + y + "," + Health + "," + Team);
                    if (temp[4] == "Blue")
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("archer2.png");
                        picture[count2].Name = "BA" + (count2 + 1);
                    }
                    else
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("archer.png");
                        picture[count2].Name = "RA" + (count2 + 1);
                    }

                    createdUnit = new RangedUnit(temp[0], int.Parse(temp[1]), int.Parse(temp[2]), int.Parse(temp[3]), 8,15,2,temp[4], picture[count2].Name);
                    numOfA++;
                }
                else
                {
                    //melee
                    if (temp[4] == "Blue")
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("Warrior2.png");
                        picture[count2].Name = "BW" + (count2 + 1);
                    }
                    else
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("Warrior.png");
                        picture[count2].Name = "RW" + (count2 + 1);
                    }
                    createdUnit = new MeleeUnit(temp[0], int.Parse(temp[1]), int.Parse(temp[2]), int.Parse(temp[3]), 8, 15, 2, temp[4], picture[count2].Name);
                    numOfW++;
                }
                loadedUnits[c] = createdUnit;
         //     Console.WriteLine(createdUnit.ToString());
           
                line = reader.ReadLine();
                c++;

                fm.Controls.Add(picture[count2]);
                list[count] = createdUnit;
                count++;
                count2++;
            }
            Console.WriteLine("Data read");
            reader.Close();
            saveFile.Close();
        //    list = loadedUnits;
           
        }

        public void loadbuilding()
        {
            FileStream saveFile = new FileStream("saves/buildings.game", FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(saveFile);
            int numBuildings = File.ReadAllLines("saves/buildings.game").Length;
            Building[] loadedBuildings = new Building[numBuildings];
            int c2 = 0;
            string line = reader.ReadLine();
            Building createdBuilding = null;

            while (line != null)
            {
                string[] temp = line.Split(',');
                //determine what unit to make
                //build the unit
                //assign the unit to the array
                Point newpoint = new Point(int.Parse(temp[2]), int.Parse(temp[1]));
                UnitLoc[count2] = newpoint;
                Size newsize = new Size(20, 20);
                //           MessageBox.Show(count.ToString());

                picture[count2] = new PictureBox();
                //     picture[count].Parent =  ;
                picture[count2].Location = newpoint;
                picture[count2].Size = newsize;
                picture[count2].SizeMode = PictureBoxSizeMode.Zoom;
                if ((temp[0] == "Gold mine"))
                {
                    if (temp[4] == "Blue")
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("resourcebuild2.png");
                        picture[count2].Name = "RB" + (count2 + 1);
                    }
                    else
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("resourcebuild1.png");
                        picture[count2].Name = "RB" + (count2 + 1);
                    }
                    //(this.name + "," + X + "," + y + "," + Health + "," + Team+","+ Remain);
                    createdBuilding = new ResourceBuilding(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2]), temp[4], picture[count2].Name);
                    createdBuilding.Health = Convert.ToInt32(temp[3]);
                    createdBuilding.Remain = Convert.ToInt32(temp[5]);
                    numOfR++;
                }
                else
                {
                    //factory
                    if (temp[4] == "Blue")
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("factorybuild2.png");
                        picture[count2].Name = "RB" + (count2 + 1);
                    }
                    else
                    {
                        picture[count2].Image = (Bitmap)Image.FromFile("factorybuild1.png");
                        picture[count2].Name = "RB" + (count2 + 1);
                    }
                    //(this.name + "," + X + "," + y + "," + Health + "," + Team+","+ Remain);
                    createdBuilding = new FactoryBuilding(Convert.ToInt32(temp[1]), Convert.ToInt32(temp[2]), temp[4], picture[count2].Name);
                    createdBuilding.Health = Convert.ToInt32(temp[3]);
                   
                    numOfF++;

                }
                loadedBuildings[c2] = createdBuilding;
        
                line = reader.ReadLine();
                c2++;

                fm.Controls.Add(picture[count2]);

                count2++;
                bcount++;
            }
            Console.WriteLine("Data read");
            reader.Close();
            saveFile.Close();
            buildlist = loadedBuildings;
        }


    }
}
