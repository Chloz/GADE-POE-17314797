﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assigment_1  //2
{  [Serializable]
    class ResourceBuilding : Building
    {
        public int gold;
     


        public ResourceBuilding(int x, int y,string team, string pic)
        {

            gold = 0;
            this.amount = 2;
            this.remain = 100;
            this.xPosition = x;
            this.yPosition = y;
            this.health = 100;
            this.team = team;
            this.image = pic;
            this.name = "Gold mine";

        }


        public override int X
        {
            get
            {
                return xPosition;
            }

            set
            {
                xPosition = value;
            }
        }

        public override int y
        {
            get { return yPosition; }
            set { yPosition = value; }
        }
        public override int Health
        {
            get { return health; }
            set { health = value; }
        }
        public override string Type
        {
            get { return type; }
            set { type = value; }
        }
        public override string Team
        {
            get { return team; }
            set { team = value; }
        }
        public override int Remain
        {
            get { return remain; }
            set { remain = value; }
        }
        public override int Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        public override string Image
        {
            get { return image; }
            set { image = value; }
        }

        public override void Save()
        {
            FileStream saveFile = new FileStream("saves/buildings.game", FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(saveFile);

            writer.WriteLine(this.name + "," + X + "," + y + "," + Health + "," + Team + "," + Remain);
            Console.WriteLine("Data written");
            writer.Close();
            saveFile.Close();
        }

        public override void Load()
        {
      //      throw new NotImplementedException();
        }

        public override void movement(ref int Tgold) 
        {
             if (remain > 0)
            {
                Tgold += 2;
                remain -= 2;
            }       
        }

        public override bool product()
        {
            // nothing
            return true;

        }

        public override string unit()
        {
            // nothing
            return "";

        }

        public override int Getxposition() // return this x position, units spawn on the point of the factory building
        {
            return xPosition;
        }
        public override int Getyposition()
        {
            return yPosition;
        }

        public override void TakeDamge(Unit a)
        {

            if (a.inRangeB() == true) // if in range then attack
            {

                health -= a.CalDamage();
                if (health <= 0)
                {
                    health = 0;
                    death();
                }

            }
        }
        public override int gethealth()
        {
            return health;
        }

        public override string Getname()
        {
            return name;
        }

        public override string Getimagename()
        {
            return image;
        }

        public override string Getteam()
        {
            return team;
        }

        public override bool death()
        {
            if (gethealth() == 0)
            {
                return true;
            }
            else {
                return false;
            }

           
        }
        public override string Tostring()
        {
            return team + " Goldmine HP: " + health + " Gold remain: "+remain;
        }

    }
}
