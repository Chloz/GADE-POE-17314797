﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoom : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //Zoom out  
        
        if (Input.GetAxis("Mouse ScrollWheel") < 0)
        {
            if (Camera.main.fieldOfView <= 10)
                Camera.main.fieldOfView += 2;
            if (Camera.main.orthographicSize <= 16)
                Camera.main.orthographicSize += 0.5F;
        }
        //Zoom in  
        if (Input.GetAxis("Mouse ScrollWheel") > 0)
        {
            if (Camera.main.fieldOfView > 0)
                Camera.main.fieldOfView -= 2;
            if (Camera.main.orthographicSize >= 2)
                Camera.main.orthographicSize -= 0.5F;
        }
    }
}
