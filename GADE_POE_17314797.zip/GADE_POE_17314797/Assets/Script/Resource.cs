﻿using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;

public class Resource : Building{

    // Use this for initialization
    public int iron;
    public int wood;
    public int remain;
  //  public enum type : int {iron , wood }
    public Resource(string name, float x, float y, int health, string team)
    {
        iron = 0;
        wood = 0;
        remain = 100;
        this.xPosition = x;
        this.yPosition = y;
        this.health = health;
      
        this.team = team;

        this.name = name;
    }

    
    public override void Generate(int num ,GameObject s ,ref Unit nothing)
    {
    //    Debug.Log(num);
        if (remain > 0)
        {
            if (num == 0)
            {
                iron++;
                //        Debug.Log(GameObject.Find("Map").GetComponent<Map>().iron);
                if (team == "Red")
                { GameObject.Find("Map").GetComponent<Map>().riron++; }
                else
                { GameObject.Find("Map").GetComponent<Map>().biron++; }
                
               

            }
            else if (num == 1)
            {
                wood++;
                //          Debug.Log(GameObject.Find("Map").GetComponent<Map>().wood);
                if (team == "Red")
                { GameObject.Find("Map").GetComponent<Map>().rwood++; }
                else
                { GameObject.Find("Map").GetComponent<Map>().bwood++; }
            }

            remain--;
            Debug.Log(remain);
        }

    }




    public override float X
    {
        get
        {
            return xPosition;
        }

        set
        {
            xPosition = value;
        }
    }

    public override float y
    {
        get { return yPosition; }
        set { yPosition = value; }
    }
    public override int Health
    {
        get { return health; }
        set { health = value; }
    }



    public override string Team
    {
        get { return team; }
        set { team = value; }
    }
   
    public override string Name
    {
        get { return name; }
        set { name = value; }
    }

    public override float Getxposition()
    {
        return xPosition;
    }
    public override float Getyposition()
    {
        return yPosition;
    }
    public override int Gethealth()
    {
        return health;
    }
    public override string Getteam()
    {
        return team;
    }

 

    public override bool Isdead()
    {
        if (health <= 0)
            return true;
        else return false;
    }
    public override string ToString()
    {
        return Team + " " + Name + "\n" + "(" + X + "," + y + ") \n Hp:" + Health + " / 60"
                    +"\nGenerate 1 iron or 1 wood per sec\nRemain resource " +remain;
    }
}
