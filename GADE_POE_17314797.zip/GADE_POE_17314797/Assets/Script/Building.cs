﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Building  {

    // Use this for initialization

    protected float xPosition;
    protected float yPosition;
    protected int health;
    protected string team;
    protected string name;

    public abstract float X
    {
        get;
        set;
    }

    public abstract float y
    {
        get;
        set;
    }
    public abstract int Health
    {
        get;
        set;
    }

    public abstract string Team
    {
        get;
        set;
    }
 

    public abstract string Name
    {
        get;
        set;
    }

    public abstract void Generate(int random , GameObject s, ref Unit t);
    public abstract float Getxposition();
    public abstract float Getyposition();
    public abstract int Gethealth();
    public abstract string Getteam();
    public abstract bool Isdead();
    public abstract override string ToString();
}
