﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Unit {

    // Use this for initialization

    protected float xPosition;
    protected float yPosition;
    protected int health;
    protected int speed;
    protected int attack;
    protected string team;
    protected string name;

    public abstract float X
    {
        get;
        set;
    }

    public abstract float y
    {
        get;
        set;
    }
    public abstract int Health
    {
        get;
        set;
    }
    public abstract int Speed
    {
        get;
        set;
    }
    public abstract string Team
    {
        get;
        set;
    }
    public abstract int Attack
    {
        get;
        set;
    }
 
    public abstract string Name
    {
        get;
        set;
    }

    public abstract float Getxposition();
    public abstract float Getyposition();
    public abstract int Gethealth();
    public abstract string Getteam();
    public abstract void Closet();
    public abstract void Combat(GameObject s);
    public abstract bool Isdead();
    public abstract override string ToString();

}
