﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceBuilding : MonoBehaviour {



    // Use this for initialization
    public Resource building;
    public int maxhealth;
    public int hp;
    public Building thisBuilding;
    public float fireRate;
    public Unit a;
    public string Text;
    public bool dead;
    void Start () {
        fireRate = 0;

        GameObject s = this.gameObject;
        float x = s.gameObject.transform.position.x;
        float y = s.gameObject.transform.position.z; //
         a = new Meele("Warrior", x, y, 20, 5, 2, this.gameObject.tag); //ignore
        maxhealth = 60;
        building = new Resource("Resource",x,y,maxhealth,s.tag);

        thisBuilding = s.gameObject.GetComponent<ResourceBuilding>().building; //testing
        
    }
	
	// Update is called once per frame
	void Update () {
        dead = thisBuilding.Isdead();
        if (Time.time > fireRate)
        {
            
            fireRate= Time.time + 1.0f;
            Debug.Log(fireRate);
            
            building.Generate(Random.Range(0, 2), this.gameObject, ref a);//ref here will not do any to resource
            thisBuilding.X = this.transform.position.x;
            thisBuilding.y = this.transform.position.z;
        }
        hp = thisBuilding.Health;
        Text = thisBuilding.ToString();
      
    }
}
