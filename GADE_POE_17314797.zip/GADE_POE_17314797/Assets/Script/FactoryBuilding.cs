﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FactoryBuilding : MonoBehaviour {

    // Use this for initialization
    public Factory building;
    public int maxhealth;
    public int hp;
    public Building thisBuilding;
    public float fireRate;
    public Unit a;
    public GameObject warrior;
    public GameObject archer;
    public string Text;
    public bool dead;
    void Start()
    {
        fireRate = 0;

        GameObject s = this.gameObject;
        float x = s.gameObject.transform.position.x;
        float y = s.gameObject.transform.position.z; //
         a = new Meele("Warrior", x, y, 20, 5, 2, this.gameObject.tag);
        maxhealth = 80;
        building = new Factory("Factory", x, y, maxhealth, s.tag);

        thisBuilding = s.gameObject.GetComponent<FactoryBuilding>().building; //testing
    }

    // Update is called once per frame
    float time;
    void Update () {
        dead = thisBuilding.Isdead();

        if (Time.time > fireRate)
        {

            fireRate = Time.time + 5.0f; //generate every 5 sec;
           
            Debug.Log(fireRate);
           
            
            building.Generate(Random.Range(0, 2), this.gameObject, ref a);
            thisBuilding.X = this.transform.position.x;
            thisBuilding.y = this.transform.position.z;


            float x = this.transform.position.x + 2;
            float y = this.transform.position.y;
            float z = this.transform.position.z + 2;
            if (a.Name == "Warrior")
            {
                Instantiate(warrior, new Vector3(x, y, z), Quaternion.identity); // generate 1 object
            }
            else if(a.Name =="Archer")
            {
                Instantiate(archer, new Vector3(x, y, z), Quaternion.identity); // generate 1 object
            }

        }
        hp = thisBuilding.Health;
        time = fireRate - Time.time;
        Text = thisBuilding.ToString()+"\nGenerate "+a.Name+" in "+time +" sec";
        
    }
}
