﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Map : MonoBehaviour {

    // Use this for initialization
    public GameObject RedWarrior;
    public GameObject BlueWarrior;

    public GameObject RedArcher;
    public GameObject BlueArcher;

    public GameObject RedResource;
    public GameObject BlueResource;

    public GameObject RedFactory;
    public GameObject BlueFactory;

    public GameObject[] Red;
    public GameObject[] Blue;

    public int riron;
    public int rwood;

    public int biron;
    public int bwood;


    public int Timecount;
    public int beginGeneration;
    public int num;
    Text time;
    Text red;
    Text blue;
    Text win;
    Text info;
    private int sec;
    private int min;
    private bool wins;

    void Start () {
        Generate();
        Timecount = 0;
        riron = 0;
        rwood = 0;
        biron = 0;
        bwood = 0;
        sec = 0;
        min = 0;
         time = GameObject.Find("Canvas/Time").GetComponent<Text>();
         red = GameObject.Find("Canvas/Red").GetComponent<Text>();
         blue = GameObject.Find("Canvas/Blue").GetComponent<Text>();
        win = GameObject.Find("Canvas/Win").GetComponent<Text>();
        info = GameObject.Find("Canvas/Info").GetComponent<Text>();
        win.text = " ";
        wins = false;
    }
	
	// Update is called once per frame
	void Update () {
        Red = GameObject.FindGameObjectsWithTag("Red");
        Blue = GameObject.FindGameObjectsWithTag("Blue");
        if (Time.fixedTime > Timecount)
        {
            //     Debug.Log(Camera.main.orthographicSize);
            Timecount++;
            sec++;
            if (sec == 60)
            {
                sec = 0;
                min++;
            }
            time.text = min + ":" + sec;
            red.text = "Red\nIron:" + riron + "\nWood:" + rwood + "\n" + Red.Length;
            blue.text = "Blue\nIron:" + biron + "\nWood:" + bwood + "\n" + Blue.Length;
            if (Red.Length == 0)
            {
                time.text = " ";
                red.text =" ";
                blue.text = " ";
                win.text = "Victory\nRed";
            //    info.text = " ";
                wins = true;
            }
            else if (Blue.Length == 0)
            {
                time.text = " ";
                red.text = " ";
                blue.text = " ";
                win.text = "Victory\nBlue";
          //      info.text = " ";
                wins = true;
            }

            //      Debug.Log(Timecount);
        }

        if (wins == true)
        {
            info.text = " ";
        }

        
        

        
	}

    public void Generate()
    {
        num = Random.Range(5, 8);
        for (int i = 0; i < num; i++)
        {
            RedWarrior.name = "Warrior";
            Instantiate(RedWarrior, new Vector3(Random.Range(-50, 50), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }


        num = Random.Range(5, 8);
        for (int i = 0; i < num; i++)
        {
            BlueWarrior.name = "Warrior";
            Instantiate(BlueWarrior, new Vector3(Random.Range(-50, 50), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(5, 8);
        for (int i = 0; i < num; i++)
        {
            RedArcher.name = "Archer";
            Instantiate(RedArcher, new Vector3(Random.Range(-50, 50), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(5, 8);
        for (int i = 0; i < num; i++)
        {
            BlueArcher.name = "Archer";
            Instantiate(BlueArcher, new Vector3(Random.Range(-50, 50), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(3, 6);
        for (int i = 0; i < num; i++)
        {
            RedResource.name = "Resource";
            Instantiate(RedResource, new Vector3(Random.Range(-65, 65), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(3, 6);
        for (int i = 0; i < num; i++)
        {
            BlueResource.name = "Resource";
            Instantiate(BlueResource, new Vector3(Random.Range(-65, 65), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(3, 5);
        for (int i = 0; i < num; i++)
        {
            RedFactory.name = "Factory";
            Instantiate(RedFactory, new Vector3(Random.Range(-65, 65), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }

        num = Random.Range(3, 5);
        for (int i = 0; i < num; i++)
        {
            BlueFactory.name = "Factory";
            Instantiate(BlueFactory, new Vector3(Random.Range(-65, 65), 0.5f, Random.Range(-50, 50)), Quaternion.identity);
        }
    }

    public void UI()
    {
       
    }

}
