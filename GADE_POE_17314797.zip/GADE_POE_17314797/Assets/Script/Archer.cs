﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Archer : MonoBehaviour {

    public Ranged unit;
    public int maxhealth;
    public Unit thisunit;
    public GameObject enemy;
    public int hp;
    public float fireRate;
    public string Text;
    public bool dead;
    void Start()
    {
        fireRate = 0;
        GameObject s = this.gameObject;
        float x = s.gameObject.transform.position.x;
        float y = s.gameObject.transform.position.z; //
        maxhealth = 18;

        unit = new Ranged("Archer", x, y, maxhealth, 4, 3, s.tag);
        Debug.Log(unit.Team);

        thisunit = s.gameObject.GetComponent<Archer>().unit;
    }

    // Update is called once per frame
    void Update()
    {
        dead = thisunit.Isdead();
        closet();
        thisunit.X = this.transform.position.x;
        thisunit.y = this.transform.position.z;
        hp = thisunit.Health;
        Text = thisunit.ToString();
      
    }

    public void closet()
    {
      //  Debug.Log(this.gameObject.tag);
        if (this.gameObject.tag == "Red")
        {

            GameObject[] list = GameObject.FindGameObjectsWithTag("Blue"); // enemy tag
            if (list.Length > 0) // check if the enemy still exist

            {
                float distance = 10000000000000000000;  // reset the max distance every time when this method being call
                Vector3 m = this.gameObject.transform.position; // return the object position
                                                                //    Debug.Log(m);
                int num1 = 0;  //ignore



                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i] != this.gameObject) // ignore
                    {
                        Vector3 n = list[i].transform.position;
                        if (distance > Vector3.Distance(m, n))
                        {
                            //      Debug.Log(Vector3.Distance(m, n));
                            distance = Vector3.Distance(m, n);
                            num1 = i;

                            enemy = list[num1];

                        }
                    }

                }

                if (distance > 5)
                {
                    move();
                }
            }
            else
            {

            }

        }
        else if (this.gameObject.tag == "Blue")
        {
            GameObject[] list = GameObject.FindGameObjectsWithTag("Red"); // enemy tag
            if (list.Length > 0)  
            {
                float distance = 10000000000000000000;  // reset the max distance every time when this method being call
                Vector3 m = this.gameObject.transform.position; // return the object position
                                                                //    Debug.Log(m);
                int num1 = 0;  //ignore



                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i] != this.gameObject) // ignore
                    {
                        Vector3 n = list[i].transform.position;
                        if (distance > Vector3.Distance(m, n))
                        {
                            //      Debug.Log(Vector3.Distance(m, n));
                            distance = Vector3.Distance(m, n);
                            num1 = i;

                            enemy = list[num1];

                        }
                    }

                }

                if (distance > 5)
                {
                    move();
                }
            }
            else
            { }

        }


      
    }
    public void move()
    {
        //  transform.position += (enemy.transform.position - transform.position).normalize * Time.deltatime * speed
        this.gameObject.transform.LookAt(enemy.transform);               
        this.gameObject.transform.Translate(Vector3.forward * Time.deltaTime * 4);
    }

    void OnTriggerStay(Collider other) //other is that enemy object
    {
     

        if (other.gameObject.tag != this.gameObject.tag || other.gameObject.tag != "Untagged" ||other.gameObject!= null)
        {


            GameObject go = other.gameObject;
            this.gameObject.transform.LookAt(go.transform);
            if (go.name == "Warrior" || go.name == "Warrior(Clone)")
            {
                if (go.gameObject.GetComponent<Warrior>().dead == false)
                {

                    if (Time.time > fireRate)
                    {
                        fireRate = Time.time + 1.3f;
                        //       Debug.Log(fireRate);
                        thisunit.Combat(go);
                    }
                }
                else
                {
                    Debug.Log(go.name + "Dead kill by" + this.gameObject.name);
                    Destroy(go);
                }
            }
            else if (go.name == "Archer" || go.name == "Archer(Clone)")
            {
                if (go.gameObject.GetComponent<Archer>().dead == false)
                {

                    if (Time.time > fireRate)
                    {
                        fireRate = Time.time + 1.3f;
                        //       Debug.Log(fireRate);
                        thisunit.Combat(go);
                    }
                }
                else
                {
                    Debug.Log(go.name + "Dead kill by" + this.gameObject.name);
                    Destroy(go);
                }
            }
            else if (go.name == "Resource" || go.name == "Resource(Clone)")
            {
                if (go.gameObject.GetComponent<ResourceBuilding>().dead == false)
                {

                    if (Time.time > fireRate)
                    {
                        fireRate = Time.time + 1.3f;
                        //       Debug.Log(fireRate);
                        thisunit.Combat(go);
                    }
                }
                else
                {
                    Debug.Log(go.name + "Dead kill by" + this.gameObject.name);
                    Destroy(go);
                }
            }
            else if (go.name == "Factory" || go.name == "Factory(Clone)")
            {


                if (go.gameObject.GetComponent<FactoryBuilding>().dead == false)
                {

                    if (Time.time > fireRate)
                    {
                        fireRate = Time.time + 1.3f;
                        //       Debug.Log(fireRate);
                        thisunit.Combat(go);
                    }
                }
                else
                {
                    Debug.Log(go.name + "Dead kill by" + this.gameObject.name);
                    Destroy(go);
                }

            }
        }

    }
}
