﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ranged : Unit {

    // Use this for initialization
    public Ranged(string name, float x, float y, int health, int speed, int attack, string team)
    {
        this.xPosition = x;
        this.yPosition = y;
        this.health = health;
        this.speed = speed;
        this.attack = attack;

        this.team = team;

        this.name = name;




    }

    public override float X
    {
        get
        {
            return xPosition;
        }

        set
        {
            xPosition = value;
        }
    }

    public override float y
    {
        get { return yPosition; }
        set { yPosition = value; }
    }
    public override int Health
    {
        get { return health; }
        set { health = value; }
    }

    public override int Speed
    {
        get { return speed; }
        set { speed = value; }
    }

    public override string Team
    {
        get { return team; }
        set { team = value; }
    }
    public override int Attack
    {
        get { return attack; }
        set { attack = value; }
    }
    public override string Name
    {
        get { return name; }
        set { name = value; }
    }

    public override float Getxposition()
    {
        return xPosition;
    }
    public override float Getyposition()
    {
        return yPosition;
    }
    public override int Gethealth()
    {
        return health;
    }
    public override string Getteam()
    {
        return team;
    }

    public override void Closet()
    {

    }
    public override void Combat(GameObject s)
    {
        if (s.gameObject.name == "Warrior" || s.gameObject.name == "Warrior(Clone)")
        {   

            s.gameObject.GetComponent<Warrior>().thisunit.Health -= this.Attack;
        }
        else if (s.gameObject.name == "Archer" || s.gameObject.name == "Archer(Clone)")
        {
            s.gameObject.GetComponent<Archer>().thisunit.Health -= this.Attack; 
         
        }
        else if (s.gameObject.name == "Resource" || s.gameObject.name == "Resource(Clone)")
        {
            s.gameObject.GetComponent<ResourceBuilding>().thisBuilding.Health -= this.Attack;
        }
        else if (s.gameObject.name == "Factory" || s.gameObject.name == "Factory(Clone)")
        {
            s.gameObject.GetComponent<FactoryBuilding>().thisBuilding.Health -= this.Attack;
        }
    }

    public override bool Isdead()
    {
        if (health <= 0)
            return true;
        else return false;
    }

    public override string ToString()
    {
        return Team + " " + Name + "\n" + "(" + X + "," + y + ") \n Hp:" + Health + " / 18\nAttack: 3 per 1.0 sec\nCost 4 Wood";
    }
}
