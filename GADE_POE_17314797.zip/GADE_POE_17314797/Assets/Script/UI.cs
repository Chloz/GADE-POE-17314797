﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI : MonoBehaviour {

    // Use this for initialization
    Text text;
    GameObject go;
    private bool click;
	void Start () {
		text = GameObject.Find("Canvas/Info").GetComponent<Text>();
        text.text = "Floor";
        click = false;
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            click = true;
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);


            if (Physics.Raycast(ray, out hit) )
            {    
                
                 go = hit.collider.gameObject;
         //       string name = (string)hit.collider.name;
       //         float x = (float)hit.collider.transform.position.x;
     //           float y = (float)hit.collider.transform.position.z;
                
                
             //   Debug.Log(name + " " +x + " " + y);


            }

        }
        if (go == null)
        {   if (click ==true)
            {
                text.text = "Dead";
            }
        }
        else
        {
            if (go.tag != "Untagged")
            {
                if (go.name == "Warrior" || go.name == "Warrior(Clone)")
                {
                    text.text = go.GetComponent<Warrior>().Text;
                }
                else if (go.name == "Archer" || go.name == "Archer(Clone)")
                {
                    text.text = go.GetComponent<Archer>().Text;
                }
                else if (go.name == "Resource" || go.name == "Resource(Clone)")
                {
                    text.text = go.GetComponent<ResourceBuilding>().Text;
                }
                else if (go.name == "Factory" || go.name == "Factory(Clone)")
                {
                    text.text = go.GetComponent<FactoryBuilding>().Text;
                }

            }
            else if (go.tag == "Untagged")
            {
                text.text = go.name;
            }

        }


    }
}
